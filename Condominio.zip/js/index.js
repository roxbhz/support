var teste = 1;

console.log('testea');
console.log(teste);